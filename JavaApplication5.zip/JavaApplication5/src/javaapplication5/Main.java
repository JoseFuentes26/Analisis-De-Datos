package javaapplication5;
import java.util.Scanner;
import Libreria.Venta; 
public class Main        
{
    
    public static void main(String[] args) 
    { Scanner input =new Scanner (System.in);
    String resp;
    do
    { System.out.println("Ingrese el tipo de chocolate que desea comprar");
       String tipo  = input.next();
       System.out.println("Ingrese la cantidad que desea comprar");
       int cantidad = input.nextInt();
       Venta objVenta = new Venta ( tipo, cantidad);
      System.out.println("¿Desea continuar?(Si/No)");
      resp= input.next();
      
        } 
    while (resp.equalsIgnoreCase("Si")); 
    
    
    
    
    
    } 
    
}
