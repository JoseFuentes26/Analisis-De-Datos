
package Libreria;
public class Venta 
{
  private String tipodeChocolate;
  private int cantidad;
  private double ImportedeCompra, Descuento, PrecioUnidad, ImporteaPagar;
  
  public Venta (String tipoChocolate, int cantidad) 
  {
     this.tipodeChocolate = tipoChocolate;
     this.cantidad = cantidad;      
  }
  public Venta () 
  {
     this.tipodeChocolate = "";
     this.cantidad = 0;
  }
    public double getImporteCompra() { return ImportedeCompra; }
    public double getDescuento() { return Descuento; }
    public double getImportePagar() { return ImporteaPagar; }
    public String getTipoChocolate() { return tipodeChocolate; }
    public void setTipoChocolate(String tipoChocolate) { this.tipodeChocolate = tipoChocolate; }
    public int getCantidad() { return cantidad; }
    public void setCantidad(int cantidad) { this.cantidad = cantidad; }
    public double getPrecioUnitario() { return PrecioUnidad; }
    public void setPrecioUnitario(double PrecioUnitario) { this.PrecioUnidad = PrecioUnitario; }
    
  public double calculoPrecio()
  {
      switch(this.tipodeChocolate.toLowerCase().trim())
      {
          case "primor":
              return 8.5;
          case "Dulzura":
              return 10;    
          case "Tentacion":
              return 7;    
          case "Explosion":
              return 12.5;
          default: System.out.println("Ese chocolate no existe");
              return 0.00;                 
      }
  }    
  public double calculoDescuento()
  {
   if (cantidad>5)
       return (this.PrecioUnidad * this.cantidad) * 0.04;
   else
        if (cantidad>=5 && cantidad<10)
            return (this.PrecioUnidad * this.cantidad) * 0.065;
        else
            if (cantidad>=10 && cantidad<15)
                return (this.PrecioUnidad * this.cantidad) * 0.09;
            else
                if (cantidad>=15)
                    return(this.PrecioUnidad * this.cantidad) * 0.115;
                else 
                    return 0.00;
      
  }  
    
}
