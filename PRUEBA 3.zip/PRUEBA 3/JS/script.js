// ===============================
//        UTILS
// ===============================
function getArray() {
    return document.getElementById("inputArray").value
        .split(",")
        .map(n => parseInt(n.trim()));
}

// ===============================
//     1. SHELL SORT
// ===============================
function shellSort(arr) {
    // Algoritmo divide y vencerás para ordenar
    let gap = Math.floor(arr.length / 2);
    while (gap > 0) {
        for (let i = gap; i < arr.length; i++) {
            let temp = arr[i];
            let j = i;

            while (j >= gap && arr[j - gap] > temp) {
                arr[j] = arr[j - gap];
                j -= gap;
            }
            arr[j] = temp;
        }
        gap = Math.floor(gap / 2);
    }
    return arr;
}

function runShellSort() {
    const arr = getArray();
    document.getElementById("sortOutput").textContent =
        "Shell Sort Result:\n" + shellSort(arr);
}

// ===============================
//     2. QUICK SORT
// ===============================
function quickSort(arr) {
    // Algoritmo recursivo divide y vencerás
    if (arr.length <= 1) return arr;

    const pivot = arr[arr.length - 1];
    let left = [];
    let right = [];

    for (let i = 0; i < arr.length - 1; i++) {
        arr[i] < pivot ? left.push(arr[i]) : right.push(arr[i]);
    }

    return [...quickSort(left), pivot, ...quickSort(right)];
}

function runQuickSort() {
    const arr = getArray();
    document.getElementById("sortOutput").textContent =
        "QuickSort Result:\n" + quickSort(arr);
}

// ===============================
//    3. BÚSQUEDA LINEAL
// ===============================
function linearSearch(arr, target) {
    for (let i = 0; i < arr.length; i++) {
        if (arr[i] === target) return i;
    }
    return -1;
}

function runLinearSearch() {
    const arr = getArray();
    const target = parseInt(document.getElementById("searchValue").value);

    let result = linearSearch(arr, target);

    document.getElementById("searchOutput").textContent =
        result >= 0
        ? `Búsqueda lineal: encontrado en índice ${result}`
        : "No encontrado.";
}

// ===============================
//    4. BÚSQUEDA BINARIA
// ===============================
function binarySearch(arr, target) {
    arr.sort((a, b) => a - b);
    let low = 0, high = arr.length - 1;

    while (low <= high) {
        let mid = Math.floor((low + high) / 2);

        if (arr[mid] === target) return mid;
        else if (arr[mid] < target) low = mid + 1;
        else high = mid - 1;
    }

    return -1;
}

function runBinarySearch() {
    const arr = getArray();
    const target = parseInt(document.getElementById("searchValue").value);

    let result = binarySearch(arr, target);

    document.getElementById("searchOutput").textContent =
        result >= 0
        ? `Búsqueda binaria: encontrado en índice ordenado ${result}`
        : "No encontrado.";
}

// ===============================
//      5. RECURSIVIDAD
// ===============================
function factorial(n) {
    if (n === 0) return 1;
    return n * factorial(n - 1); // llamada recursiva
}

function runFactorial() {
    document.getElementById("recursionOutput").textContent =
        "Factorial(5) = " + factorial(5);
}

function fibonacci(n) {
    if (n <= 1) return n;
    return fibonacci(n - 1) + fibonacci(n - 2);
}

function runFibonacci() {
    document.getElementById("recursionOutput").textContent =
        "Fibonacci(6) = " + fibonacci(6);
}

// ===============================
//      6. BACKTRACKING
// ===============================
function combinationSum(arr, target) {
    let result = [];

    function backtrack(current, start, total) {
        if (total === target) {
            result.push([...current]);
            return;
        }
        if (total > target) return;

        for (let i = start; i < arr.length; i++) {
            current.push(arr[i]);
            backtrack(current, i, total + arr[i]);
            current.pop(); // deshacer (vuelta atrás)
        }
    }

    backtrack([], 0, 0);
    return result;
}

function runBacktracking() {
    const arr = getArray();
    const target = parseInt(document.getElementById("targetValue").value);

    let result = combinationSum(arr, target);

    document.getElementById("backtrackingOutput").textContent =
        JSON.stringify(result, null, 2);
}
